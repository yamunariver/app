"use client";

import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ArrowLeft } from "lucide-react";
import Link from "next/link";

interface Record {
  id: string;
  pisNumber: string;
  name: string;
  ipAddress: string;
  macAddress: string;
  switchIp: string;
  switchPort: string;
  ext: string;
  domain: "YES" | "NO";
  antivirus: "YES" | "NO";
  createdAt: string;
}

export default function RecentRecords() {
  // Mock data - replace with actual API call
  const recentRecords: Record[] = [
    {
      id: "1",
      pisNumber: "PIS123",
      name: "John Doe",
      ipAddress: "192.168.1.1",
      macAddress: "00:1B:44:11:3A:B7",
      switchIp: "192.168.0.1",
      switchPort: "Gi1/0/1",
      ext: "1234",
      domain: "YES",
      antivirus: "YES",
      createdAt: "2024-03-20T10:30:00Z",
    },
  ];

  return (
    <main className="min-h-screen p-8 bg-background">
      <div className="max-w-4xl mx-auto space-y-8">
        <div className="flex items-center gap-4">
          <Link href="/">
            <Button variant="ghost" size="icon">
              <ArrowLeft className="h-4 w-4" />
            </Button>
          </Link>
          <h1 className="text-3xl font-bold text-primary">Recent Records</h1>
        </div>

        <div className="space-y-4">
          {recentRecords.map((record) => (
            <Card key={record.id}>
              <CardHeader>
                <CardTitle className="flex justify-between">
                  <span>{record.name}</span>
                  <span className="text-sm text-muted-foreground">
                    {new Date(record.createdAt).toLocaleString()}
                  </span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                  <div>
                    <h3 className="font-semibold">User Info</h3>
                    <p>PIS: {record.pisNumber}</p>
                    <p>Name: {record.name}</p>
                  </div>
                  <div>
                    <h3 className="font-semibold">Network Details</h3>
                    <p>IP: {record.ipAddress}</p>
                    <p>MAC: {record.macAddress}</p>
                  </div>
                  <div>
                    <h3 className="font-semibold">Switch Info</h3>
                    <p>IP: {record.switchIp}</p>
                    <p>Port: {record.switchPort}</p>
                  </div>
                  <div>
                    <h3 className="font-semibold">System Status</h3>
                    <p>EXT: {record.ext}</p>
                    <p>Domain: {record.domain}</p>
                    <p>Antivirus: {record.antivirus}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </main>
  );
}