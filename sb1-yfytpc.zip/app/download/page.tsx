"use client";

import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ArrowLeft, Download } from "lucide-react";
import Link from "next/link";

interface Building {
  id: string;
  name: string;
  recordCount: number;
}

export default function DownloadRecords() {
  // Mock data - replace with actual API call
  const buildings: Building[] = [
    { id: "1", name: "Building A", recordCount: 25 },
    { id: "2", name: "Building B", recordCount: 30 },
    { id: "3", name: "Building C", recordCount: 15 },
  ];

  const handleDownload = (buildingId: string) => {
    // Implement download logic
    console.log(`Downloading records for building ${buildingId}`);
  };

  return (
    <main className="min-h-screen p-8 bg-background">
      <div className="max-w-4xl mx-auto space-y-8">
        <div className="flex items-center gap-4">
          <Link href="/">
            <Button variant="ghost" size="icon">
              <ArrowLeft className="h-4 w-4" />
            </Button>
          </Link>
          <h1 className="text-3xl font-bold text-primary">Download Records</h1>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {buildings.map((building) => (
            <Card key={building.id}>
              <CardHeader>
                <CardTitle>{building.name}</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex justify-between items-center">
                  <p className="text-muted-foreground">
                    {building.recordCount} records
                  </p>
                  <Button
                    variant="outline"
                    onClick={() => handleDownload(building.id)}
                    className="flex items-center gap-2"
                  >
                    <Download className="h-4 w-4" />
                    Download
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        <Card className="mt-8">
          <CardHeader>
            <CardTitle>Download All Records</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex justify-between items-center">
              <p className="text-muted-foreground">
                All buildings and records combined
              </p>
              <Button
                onClick={() => handleDownload("all")}
                className="flex items-center gap-2"
              >
                <Download className="h-4 w-4" />
                Download All
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </main>
  );
}