"use client";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Search, Plus, Clock, Download } from "lucide-react";
import { useState } from "react";
import Link from "next/link";
import SearchResults from "@/components/SearchResults";

export default function Home() {
  const [searchQuery, setSearchQuery] = useState("");

  return (
    <main className="min-h-screen p-8">
      <div className="max-w-7xl mx-auto space-y-8">
        <h1 className="text-3xl font-bold text-center text-primary">
          Network Device Inventory
        </h1>
        
        {/* Main Actions Bar */}
        <div className="flex items-center gap-4 justify-between bg-card p-4 rounded-lg shadow-md">
          <div className="relative flex-1">
            <Input
              type="text"
              placeholder="Search by PIS, Name, IP, or MAC..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10"
            />
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          </div>
          
          <div className="flex gap-3">
            <Link href="/create">
              <Button variant="default" className="flex items-center gap-2">
                <Plus className="h-4 w-4" />
                Create Entry
              </Button>
            </Link>
            
            <Link href="/recent">
              <Button variant="secondary" className="flex items-center gap-2">
                <Clock className="h-4 w-4" />
                Recent Records
              </Button>
            </Link>
            
            <Link href="/download">
              <Button variant="outline" className="flex items-center gap-2">
                <Download className="h-4 w-4" />
                Download Records
              </Button>
            </Link>
          </div>
        </div>

        {/* Search Results */}
        {searchQuery && <SearchResults query={searchQuery} />}
      </div>
    </main>
  );
}