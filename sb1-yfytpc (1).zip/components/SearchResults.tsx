"use client";

import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Copy, Edit } from "lucide-react";
import { useState } from "react";
import Link from "next/link";

interface Record {
  id: string;
  pisNumber: string;
  name: string;
  ipAddress: string;
  macAddress: string;
  switchIp: string;
  switchPort: string;
  ext: string;
  domain: "YES" | "NO";
  antivirus: "YES" | "NO";
}

export default function SearchResults({ query }: { query: string }) {
  // Mock data - replace with actual API call
  const [results] = useState<Record[]>([
    {
      id: "1",
      pisNumber: "PIS123",
      name: "John Doe",
      ipAddress: "192.168.1.1",
      macAddress: "00:1B:44:11:3A:B7",
      switchIp: "192.168.0.1",
      switchPort: "Gi1/0/1",
      ext: "1234",
      domain: "YES",
      antivirus: "YES",
    },
  ]);

  return (
    <div className="bg-card p-4 rounded-lg shadow-md">
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead colSpan={2} className="text-center border-r">User Info</TableHead>
            <TableHead colSpan={2} className="text-center border-r">Network Details</TableHead>
            <TableHead colSpan={2} className="text-center border-r">Switch Info</TableHead>
            <TableHead colSpan={3} className="text-center">System Status</TableHead>
            <TableHead className="text-center">Actions</TableHead>
          </TableRow>
          <TableRow>
            <TableHead>PIS Number</TableHead>
            <TableHead className="border-r">Name</TableHead>
            <TableHead>IP Address</TableHead>
            <TableHead className="border-r">MAC Address</TableHead>
            <TableHead>Switch IP</TableHead>
            <TableHead className="border-r">Switch Port</TableHead>
            <TableHead>EXT</TableHead>
            <TableHead>Domain</TableHead>
            <TableHead className="border-r">Antivirus</TableHead>
            <TableHead className="text-right"></TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {results.map((record) => (
            <TableRow key={record.id}>
              <TableCell>{record.pisNumber}</TableCell>
              <TableCell className="border-r">{record.name}</TableCell>
              <TableCell>{record.ipAddress}</TableCell>
              <TableCell className="border-r">{record.macAddress}</TableCell>
              <TableCell>{record.switchIp}</TableCell>
              <TableCell className="border-r">{record.switchPort}</TableCell>
              <TableCell>{record.ext}</TableCell>
              <TableCell>{record.domain}</TableCell>
              <TableCell className="border-r">{record.antivirus}</TableCell>
              <TableCell>
                <div className="flex justify-end gap-2">
                  <Link href={`/edit/${record.id}`}>
                    <Button variant="ghost" size="icon">
                      <Edit className="h-4 w-4" />
                    </Button>
                  </Link>
                  <Link href={`/create?copy=${record.id}`}>
                    <Button variant="ghost" size="icon">
                      <Copy className="h-4 w-4" />
                    </Button>
                  </Link>
                </div>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  );
}