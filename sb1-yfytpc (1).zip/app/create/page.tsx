"use client";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { ArrowLeft } from "lucide-react";
import Link from "next/link";
import FileUpload from "@/components/FileUpload";

export default function CreateEntry() {
  return (
    <main className="min-h-screen p-8 bg-background">
      <div className="max-w-2xl mx-auto space-y-8">
        <div className="flex items-center gap-4">
          <Link href="/">
            <Button variant="ghost" size="icon">
              <ArrowLeft className="h-4 w-4" />
            </Button>
          </Link>
          <h1 className="text-3xl font-bold text-primary">Create New Entry</h1>
        </div>

        <FileUpload />

        <div className="relative">
          <div className="absolute inset-0 flex items-center">
            <span className="w-full border-t" />
          </div>
          <div className="relative flex justify-center text-xs uppercase">
            <span className="bg-background px-2 text-muted-foreground">
              Or create single entry
            </span>
          </div>
        </div>

        <form className="space-y-8">
          <div className="space-y-6">
            {/* User Information */}
            <div className="space-y-4">
              <h2 className="text-xl font-semibold text-primary/80">User Information</h2>
              <div className="space-y-4">
                <div className="relative">
                  <Label htmlFor="pisNumber" className="text-muted-foreground">
                    PIS Number
                  </Label>
                  <Input
                    id="pisNumber"
                    className="mt-2 border-b-2 border-primary/20 focus:border-primary transition-colors"
                    placeholder="Enter PIS Number"
                  />
                </div>
                <div className="relative">
                  <Label htmlFor="name" className="text-muted-foreground">
                    Name
                  </Label>
                  <Input
                    id="name"
                    className="mt-2 border-b-2 border-primary/20 focus:border-primary transition-colors"
                    placeholder="Enter Name"
                  />
                </div>
              </div>
            </div>

            {/* Network Details */}
            <div className="space-y-4">
              <h2 className="text-xl font-semibold text-primary/80">Network Details</h2>
              <div className="space-y-4">
                <div className="relative">
                  <Label htmlFor="ipAddress" className="text-muted-foreground">
                    IP Address
                  </Label>
                  <Input
                    id="ipAddress"
                    className="mt-2 border-b-2 border-primary/20 focus:border-primary transition-colors"
                    placeholder="Enter IP Address"
                  />
                </div>
                <div className="relative">
                  <Label htmlFor="macAddress" className="text-muted-foreground">
                    MAC Address
                  </Label>
                  <Input
                    id="macAddress"
                    className="mt-2 border-b-2 border-primary/20 focus:border-primary transition-colors"
                    placeholder="Enter MAC Address"
                  />
                </div>
              </div>
            </div>

            {/* Switch Information */}
            <div className="space-y-4">
              <h2 className="text-xl font-semibold text-primary/80">Switch Information</h2>
              <div className="space-y-4">
                <div className="relative">
                  <Label htmlFor="switchIp" className="text-muted-foreground">
                    Switch IP
                  </Label>
                  <Input
                    id="switchIp"
                    className="mt-2 border-b-2 border-primary/20 focus:border-primary transition-colors"
                    placeholder="Enter Switch IP"
                  />
                </div>
                <div className="relative">
                  <Label htmlFor="switchPort" className="text-muted-foreground">
                    Switch Port
                  </Label>
                  <Input
                    id="switchPort"
                    className="mt-2 border-b-2 border-primary/20 focus:border-primary transition-colors"
                    placeholder="Enter Switch Port"
                  />
                </div>
              </div>
            </div>

            {/* System Status */}
            <div className="space-y-4">
              <h2 className="text-xl font-semibold text-primary/80">System Status</h2>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="ext" className="text-muted-foreground">
                    Extension
                  </Label>
                  <Input
                    id="ext"
                    className="mt-2 border-b-2 border-primary/20 focus:border-primary transition-colors"
                    placeholder="Enter Extension"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="domain" className="text-muted-foreground">
                    Domain
                  </Label>
                  <Select>
                    <SelectTrigger>
                      <SelectValue placeholder="Select..." />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="YES">YES</SelectItem>
                      <SelectItem value="NO">NO</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="antivirus" className="text-muted-foreground">
                    Antivirus
                  </Label>
                  <Select>
                    <SelectTrigger>
                      <SelectValue placeholder="Select..." />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="YES">YES</SelectItem>
                      <SelectItem value="NO">NO</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </div>
          </div>

          <Button type="submit" className="w-full">
            Save Entry
          </Button>
        </form>
      </div>
    </main>
  );
}